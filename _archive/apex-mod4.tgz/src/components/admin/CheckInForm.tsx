"use client";
import { useActionState } from "react";
import { submitCheckIn, type RentalFormState } from "@/lib/actions/rental";
import { CHECKIN_ITEMS, PHOTO_ANGLES } from "@/lib/checklist";
import { PhotoAngleInput } from "@/components/admin/PhotoAngleInput";
import { SignaturePad } from "@/components/admin/SignaturePad";

const field = "w-full bg-noir border border-edge rounded-sm px-3 py-2.5 text-sm text-white focus:border-orange outline-none";
const card = "border border-edge rounded-lg bg-carbone p-5";

export function CheckInForm({ rentalId, kmDepart }: { rentalId: string; kmDepart?: number | null }) {
  const action = submitCheckIn.bind(null, rentalId);
  const [state, formAction, pending] = useActionState<RentalFormState, FormData>(action, {});

  return (
    <form action={formAction} className="space-y-5 max-w-3xl">
      <div className={card}>
        <h3 className="font-cond text-sm tracking-[2px] uppercase text-orange mb-4">Contrôles avant remise</h3>
        <div className="grid sm:grid-cols-2 gap-2.5">
          {CHECKIN_ITEMS.map((it) => (
            <label key={it.key} className="flex items-center gap-3 py-2 px-3 rounded-sm border border-edge cursor-pointer hover:border-orange/50 transition-colors">
              <input type="checkbox" name={`chk_${it.key}`} defaultChecked className="peer sr-only" />
              <span className="w-5 h-5 rounded-sm border border-gris flex items-center justify-center peer-checked:bg-orange peer-checked:border-orange text-black text-xs font-bold transition-colors">✓</span>
              <span className="font-cond text-sm text-gris-clair">{it.label}</span>
            </label>
          ))}
        </div>
      </div>

      <div className={card}>
        <h3 className="font-cond text-sm tracking-[2px] uppercase text-orange mb-4">Relevés</h3>
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="font-cond text-[11px] tracking-[1.5px] uppercase text-gris mb-1.5 block">Kilométrage au départ</label>
            <input name="km" type="number" defaultValue={kmDepart ?? ""} placeholder="Ex : 6800" className={field} />
          </div>
          <div>
            <label className="font-cond text-[11px] tracking-[1.5px] uppercase text-gris mb-1.5 block">Carburant / charge (%)</label>
            <input name="carburant" type="number" min={0} max={100} defaultValue={100} className={field} />
          </div>
        </div>
      </div>

      <div className={card}>
        <h3 className="font-cond text-sm tracking-[2px] uppercase text-orange mb-1">Photos de l'état des lieux</h3>
        <p className="font-cond text-xs text-gris mb-4">Touchez une case pour prendre ou choisir une photo.</p>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {PHOTO_ANGLES.map((a) => <PhotoAngleInput key={a.key} angleKey={a.key} label={a.label} />)}
        </div>
      </div>

      <div className={card}>
        <h3 className="font-cond text-sm tracking-[2px] uppercase text-orange mb-4">Signature du client</h3>
        <SignaturePad name="signature" />
      </div>

      {state.error && <p className="text-red-400 text-sm bg-red-400/10 border border-red-400/30 rounded-sm px-3 py-2">{state.error}</p>}

      <button type="submit" disabled={pending} className="btn-primary w-full justify-center disabled:opacity-50 sticky bottom-4">
        {pending ? "Enregistrement…" : "Valider la remise & démarrer la location →"}
      </button>
    </form>
  );
}
