import { desc } from "drizzle-orm";
import { db } from "@/lib/db";
import { StatusBadge } from "@/components/admin/StatusBadge";
import { euro, dateFr } from "@/lib/format";
import { requirePermission } from "@/lib/rbac";
import { reservations } from "@/db/schema";

export const dynamic = "force-dynamic";

export default async function ReservationsPage() {
  await requirePermission("reservation", "read");
  const list = await db.query.reservations.findMany({
    with: { vehicle: true, customer: true },
    orderBy: [desc(reservations.dateDepart)],
  });

  return (
    <div className="p-5 md:p-8 max-w-[1400px]">
      <div className="mb-6 pl-12 lg:pl-0">
        <div className="font-cond text-[11px] tracking-[3px] uppercase text-orange">Location</div>
        <h1 className="font-display text-5xl leading-none mt-1">RÉSERVATIONS</h1>
      </div>

      <div className="border border-edge rounded-lg bg-carbone overflow-x-auto">
        <table className="w-full text-sm min-w-[760px]">
          <thead>
            <tr className="font-cond text-[10px] tracking-wider uppercase text-gris border-b border-edge">
              <th className="text-left px-5 py-3 font-medium">Réf.</th>
              <th className="text-left py-3 font-medium">Véhicule</th>
              <th className="text-left py-3 font-medium">Client</th>
              <th className="text-left py-3 font-medium">Période</th>
              <th className="text-right py-3 font-medium">Montant</th>
              <th className="text-left px-5 py-3 font-medium">Statut</th>
            </tr>
          </thead>
          <tbody>
            {list.map((r) => (
              <tr key={r.id} className="border-b border-edge hover:bg-white/5 transition-colors">
                <td className="px-5 py-3.5 font-cond text-orange">{r.reference}</td>
                <td className="py-3.5">{r.vehicle?.marque} {r.vehicle?.modele}</td>
                <td className="py-3.5 text-gris-clair">
                  {r.customer ? `${r.customer.prenom ?? ""} ${r.customer.nom}` : r.contactNom ?? "—"}
                </td>
                <td className="py-3.5 text-gris-clair font-cond text-xs">{dateFr(r.dateDepart)} → {dateFr(r.dateRetour)}</td>
                <td className="py-3.5 text-right">{r.prixTotal ? euro(r.prixTotal) : "—"}</td>
                <td className="px-5 py-3.5"><StatusBadge statut={r.statut} kind="reservation" /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
